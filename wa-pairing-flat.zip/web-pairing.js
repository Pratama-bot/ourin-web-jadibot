const express = require('express');
const path = require('path');
const fs = require('fs');
const qrcode = require('qrcode');
const { default: makeWASocket, useMultiFileAuthState, DisconnectReason } = require('@whiskeysockets/baileys');
const Pino = require('pino');

const app = express();
const PORT = process.env.PORT || 3000;
const SESSION_DIR = path.join(__dirname, 'sessions');
const PENDING_SESSIONS = new Map(); // Simpan session yang sedang di-pair

// Middleware
app.use(express.json());
app.use(express.static('public'));

// Pastikan folder sessions ada
if (!fs.existsSync(SESSION_DIR)) {
  fs.mkdirSync(SESSION_DIR, { recursive: true });
}

// ============ WEB UI ============
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ============ API: GET DAFTAR BOT YANG TERSIMPAN ============
app.get('/api/bots', (req, res) => {
  try {
    const folders = fs.readdirSync(SESSION_DIR)
      .filter(f => fs.statSync(path.join(SESSION_DIR, f)).isDirectory());
    
    const bots = folders.map(folder => ({
      id: folder,
      name: folder.replace('session_', ''),
      status: PENDING_SESSIONS.has(folder) ? 'pairing' : 'saved'
    }));
    
    res.json(bots);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============ API: START PAIRING ============
app.post('/api/start-pairing', async (req, res) => {
  try {
    const { phone } = req.body;
    
    if (!phone || phone.length < 10) {
      return res.status(400).json({ error: 'Nomor WA tidak valid' });
    }

    // Generate unique session ID
    const sessionId = `session_${Date.now()}`;
    const sessionPath = path.join(SESSION_DIR, sessionId);
    
    if (!fs.existsSync(sessionPath)) {
      fs.mkdirSync(sessionPath, { recursive: true });
    }

    // Setup Baileys connection
    const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
    
    let qrString = null;
    let isConnected = false;

    const socket = makeWASocket({
      auth: state,
      printQRInTerminal: false,
      logger: Pino({ level: 'silent' }), // Silent logs
      browser: ['Chrome', 'Chrome', '121.0.6167.160'],
    });

    // Trigger QR code
    socket.ev.on('connection.update', async (update) => {
      const { connection, lastDisconnect, qr } = update;

      if (qr) {
        // Generate QR code image
        qrString = await qrcode.toDataURL(qr);
        console.log(`✓ QR Code generated for ${sessionId}`);
      }

      if (connection === 'open') {
        isConnected = true;
        console.log(`✓ Bot connected: ${sessionId}`);
      }

      if (connection === 'close') {
        const reason = new Pino().level;
        if (lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut) {
          console.log(`✗ Bot logged out: ${sessionId}`);
          PENDING_SESSIONS.delete(sessionId);
          if (fs.existsSync(sessionPath)) {
            fs.rmSync(sessionPath, { recursive: true });
          }
        }
      }
    });

    // Save credentials
    socket.ev.on('creds.update', saveCreds);

    // Simpan ke pending sessions
    PENDING_SESSIONS.set(sessionId, {
      socket,
      qr: null,
      phone,
      createdAt: Date.now(),
      isConnected: false
    });

    // Wait untuk QR code (max 15 detik)
    let attempts = 0;
    while (!qrString && attempts < 150) {
      await new Promise(r => setTimeout(r, 100));
      attempts++;
    }

    if (!qrString) {
      PENDING_SESSIONS.delete(sessionId);
      socket.end();
      return res.status(500).json({ error: 'QR Code timeout' });
    }

    res.json({
      sessionId,
      qr: qrString,
      message: 'Scan dengan HP kamu dalam 60 detik'
    });

  } catch (err) {
    console.error('Start pairing error:', err);
    res.status(500).json({ error: err.message });
  }
});

// ============ API: CEK STATUS PAIRING ============
app.get('/api/pairing-status/:sessionId', (req, res) => {
  try {
    const { sessionId } = req.params;
    const session = PENDING_SESSIONS.get(sessionId);

    if (!session) {
      return res.status(404).json({ error: 'Session tidak ditemukan' });
    }

    const elapsed = Date.now() - session.createdAt;
    const sessionPath = path.join(SESSION_DIR, sessionId);
    const isAuthenticated = fs.existsSync(path.join(sessionPath, 'creds.json'));

    if (isAuthenticated) {
      // Pairing berhasil, simpan ke DB
      const botList = JSON.parse(
        fs.readFileSync(path.join(SESSION_DIR, 'bots.json'), 'utf8') || '{}'
      );
      
      botList[sessionId] = {
        phone: session.phone,
        pairedAt: new Date().toISOString(),
        status: 'active'
      };
      
      fs.writeFileSync(
        path.join(SESSION_DIR, 'bots.json'),
        JSON.stringify(botList, null, 2)
      );

      // Hapus dari pending
      PENDING_SESSIONS.delete(sessionId);

      return res.json({
        status: 'connected',
        message: 'Bot berhasil di-pair!',
        sessionId
      });
    }

    if (elapsed > 60000) {
      // Timeout
      PENDING_SESSIONS.delete(sessionId);
      res.json({ status: 'timeout', message: 'QR Code expired' });
    } else {
      res.json({
        status: 'waiting',
        elapsed,
        message: 'Menunggu scan QR...'
      });
    }

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============ API: HUBUNGKAN BOT YANG SUDAH TERSIMPAN ============
app.post('/api/connect-bot/:sessionId', async (req, res) => {
  try {
    const { sessionId } = req.params;
    const sessionPath = path.join(SESSION_DIR, sessionId);

    if (!fs.existsSync(sessionPath)) {
      return res.status(404).json({ error: 'Session tidak ditemukan' });
    }

    const { state, saveCreds } = await useMultiFileAuthState(sessionPath);

    const socket = makeWASocket({
      auth: state,
      printQRInTerminal: false,
      logger: Pino({ level: 'silent' }),
      browser: ['Chrome', 'Chrome', '121.0.6167.160'],
    });

    socket.ev.on('creds.update', saveCreds);

    socket.ev.on('connection.update', (update) => {
      const { connection } = update;
      if (connection === 'open') {
        console.log(`✓ Reconnected: ${sessionId}`);
      }
    });

    res.json({
      status: 'connecting',
      message: 'Bot sedang connect...',
      sessionId
    });

  } catch (err) {
    console.error('Connect bot error:', err);
    res.status(500).json({ error: err.message });
  }
});

// ============ API: HAPUS BOT ============
app.delete('/api/bots/:sessionId', (req, res) => {
  try {
    const { sessionId } = req.params;
    const sessionPath = path.join(SESSION_DIR, sessionId);

    // Hapus folder session
    if (fs.existsSync(sessionPath)) {
      fs.rmSync(sessionPath, { recursive: true });
    }

    // Hapus dari bots.json
    const botListPath = path.join(SESSION_DIR, 'bots.json');
    if (fs.existsSync(botListPath)) {
      const botList = JSON.parse(fs.readFileSync(botListPath, 'utf8') || '{}');
      delete botList[sessionId];
      fs.writeFileSync(botListPath, JSON.stringify(botList, null, 2));
    }

    PENDING_SESSIONS.delete(sessionId);

    res.json({ message: 'Bot berhasil dihapus' });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`
╔═══════════════════════════════════════╗
║  🤖 WhatsApp Bot Pairing Web UI       ║
║  🌐 http://localhost:${PORT}           ║
╚═══════════════════════════════════════╝
  `);
});
