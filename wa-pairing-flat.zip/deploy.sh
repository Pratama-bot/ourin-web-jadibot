#!/bin/bash

# Deploy script untuk VPS DigitalOcean/Linode/etc
# Usage: ./deploy.sh root@your_vps_ip

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

if [ -z "$1" ]; then
    echo -e "${YELLOW}Usage:${NC}"
    echo "  ./deploy.sh user@your_vps_ip"
    echo ""
    echo "Example:"
    echo "  ./deploy.sh root@165.227.123.456"
    exit 1
fi

VPS_USER_IP=$1
DEPLOY_PATH="/root/wa-pairing"

echo -e "${YELLOW}🚀 Deploying WhatsApp Bot Pairing to $VPS_USER_IP${NC}"
echo "=========================================="

# Create zip
echo -e "${YELLOW}📦 Creating deployment package...${NC}"
zip -r deployment.zip . -x ".git/*" "node_modules/*" "sessions/*" "logs/*" ".env" "deployment.zip"

# Upload to VPS
echo -e "${YELLOW}📤 Uploading files to VPS...${NC}"
scp deployment.zip $VPS_USER_IP:$DEPLOY_PATH.zip

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Upload failed${NC}"
    exit 1
fi

# Execute setup
echo -e "${YELLOW}⚙️ Running setup on VPS...${NC}"
ssh $VPS_USER_IP << EOSSH
    echo "Extracting files..."
    cd /root
    unzip -o wa-pairing.zip -d wa-pairing
    cd wa-pairing
    
    echo "Installing dependencies..."
    npm install --production
    
    echo "Setting permissions..."
    chmod +x setup.sh deploy.sh
    mkdir -p sessions logs
    chmod 755 sessions logs
    
    echo "Create .env file..."
    if [ ! -f .env ]; then
        cp .env.example .env
    fi
    
    echo ""
    echo "=========================================="
    echo -e "✅ Deployment complete!"
    echo "=========================================="
    echo "Next steps on VPS:"
    echo "1. Edit .env: nano /root/wa-pairing/.env"
    echo "2. Run setup: bash /root/wa-pairing/setup.sh"
    echo "3. Access: http://<your_vps_ip>:3000"
    echo ""
    echo "Current files:"
    ls -la /root/wa-pairing/
EOSSH

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ VPS deployment successful!${NC}"
    rm deployment.zip
    echo ""
    echo -e "${YELLOW}Quick connect to VPS:${NC}"
    echo "ssh $VPS_USER_IP"
else
    echo -e "${RED}❌ VPS setup failed${NC}"
    exit 1
fi
