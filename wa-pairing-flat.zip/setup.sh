#!/bin/bash

# Color output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}🤖 WhatsApp Bot Pairing - Setup Script${NC}"
echo "=========================================="

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   echo -e "${RED}❌ Script harus dijalankan sebagai root${NC}"
   exit 1
fi

# Create directories
echo -e "${YELLOW}📁 Membuat folder...${NC}"
mkdir -p sessions logs

# Copy .env
if [ ! -f .env ]; then
    echo -e "${YELLOW}⚙️ Copy .env.example ke .env${NC}"
    cp .env.example .env
    echo -e "${GREEN}✓ Edit .env sesuai kebutuhan${NC}"
fi

# Install dependencies
echo -e "${YELLOW}📦 Install NPM packages...${NC}"
npm install

# Check if PM2 installed
if ! command -v pm2 &> /dev/null; then
    echo -e "${YELLOW}📦 Install PM2 globally...${NC}"
    npm install -g pm2
fi

# Setup logs
echo -e "${YELLOW}📝 Setup logging...${NC}"
mkdir -p logs
chmod 755 logs

# Ask for deployment method
echo -e "${YELLOW}🚀 Pilih metode deployment:${NC}"
echo "1) PM2 (Lightweight, recommended)"
echo "2) Docker Compose (Containerized)"
echo "3) Systemd (System service)"
read -p "Pilihan (1-3): " choice

case $choice in
    1)
        echo -e "${YELLOW}🚀 Setup dengan PM2...${NC}"
        pm2 start pm2.config.js
        pm2 save
        pm2 startup
        echo -e "${GREEN}✓ Bot started with PM2${NC}"
        echo -e "${YELLOW}Akses: http://localhost:3000${NC}"
        ;;
    2)
        echo -e "${YELLOW}🚀 Setup dengan Docker Compose...${NC}"
        if ! command -v docker &> /dev/null; then
            echo -e "${RED}❌ Docker belum terinstall${NC}"
            exit 1
        fi
        docker-compose up -d
        echo -e "${GREEN}✓ Container started${NC}"
        echo -e "${YELLOW}Akses: http://localhost:80${NC}"
        ;;
    3)
        echo -e "${YELLOW}🚀 Setup Systemd service...${NC}"
        # Create systemd service file
        cat > /etc/systemd/system/wa-pairing.service << EOF
[Unit]
Description=WhatsApp Bot Pairing Service
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$(pwd)
ExecStart=/usr/bin/node $(pwd)/web-pairing.js
Restart=always
RestartSec=10
StandardOutput=append:$(pwd)/logs/systemd.log
StandardError=append:$(pwd)/logs/systemd-error.log

[Install]
WantedBy=multi-user.target
EOF
        systemctl daemon-reload
        systemctl enable wa-pairing
        systemctl start wa-pairing
        echo -e "${GREEN}✓ Service installed dan started${NC}"
        ;;
    *)
        echo -e "${RED}❌ Pilihan tidak valid${NC}"
        exit 1
        ;;
esac

# Setup SSL (optional)
read -p "Setup SSL dengan Certbot? (y/n): " ssl_choice
if [[ $ssl_choice == "y" ]]; then
    read -p "Masukkan domain: " domain
    apt-get install certbot python3-certbot-nginx -y
    certbot certonly --standalone -d $domain -d www.$domain
    echo -e "${GREEN}✓ SSL certificate generated${NC}"
    echo -e "${YELLOW}Update nginx.conf dengan domain: $domain${NC}"
fi

echo ""
echo -e "${GREEN}✅ Setup Complete!${NC}"
echo "=========================================="
echo -e "${YELLOW}Next steps:${NC}"
echo "1. Edit .env file"
echo "2. Akses: http://localhost:3000"
echo "3. Pair bot pertama kamu"
echo ""
echo -e "${YELLOW}Useful commands:${NC}"
echo "  - PM2:     pm2 logs wa-pairing -f"
echo "  - Docker:  docker-compose logs -f wa-pairing"
echo "  - Systemd: journalctl -u wa-pairing -f"
