# 🤖 WhatsApp Bot Pairing - Web Interface

Web-based pairing interface untuk WhatsApp Bot menggunakan Baileys. Scan QR lewat browser, bot auto-login, multiple bots supported.

## ✨ Fitur

✅ **Web-based Pairing** - Scan QR lewat browser, bukan terminal  
✅ **Multi-bot Support** - Pair unlimited bots di satu server  
✅ **Auto-Login** - Bot otomatis reconnect tanpa scan QR  
✅ **Session Persistence** - Credentials tersimpan & aman  
✅ **Real-time Status** - Monitor bot connection status  
✅ **Production Ready** - PM2/Docker/Systemd support  

## 📋 Requirements

- Node.js 16+ (`node --version`)
- npm 7+ (`npm --version`)
- Linux VPS atau server (Ubuntu recommended)
- 256MB RAM minimum

## 🚀 Quick Start (5 menit)

### 1. Extract & Setup
```bash
unzip web-pairing-complete.zip
cd web-pairing-complete
chmod +x setup.sh deploy.sh
```

### 2. Run Setup
```bash
sudo bash setup.sh
```

Pilih opsi deployment:
- **1** = PM2 (Recommended untuk VPS)
- **2** = Docker (Recommended untuk production)
- **3** = Systemd (Auto-start on reboot)

### 3. Open Browser
```
http://localhost:3000
```

## 📱 Cara Pakai

### Pair Bot Baru
1. Buka `http://your_domain.com`
2. Masukkan nomor WA (format: `62xxx`)
3. Klik "Mulai Pairing"
4. Scan QR dengan HP
5. Tunggu "✅ Bot berhasil di-pair!"

### Reconnect Bot Tersimpan
1. Lihat list di "Daftar Bot"
2. Klik "Connect" - bot auto-login

### Delete Bot
Klik "Hapus" di list

## 🌐 Deploy ke VPS (DigitalOcean/Linode/etc)

### Metode 1: Otomatis (Recommended)
```bash
# Dari local machine
./deploy.sh root@your_vps_ip

# Atau dengan kunci SSH
./deploy.sh -i ~/.ssh/id_rsa root@your_vps_ip
```

### Metode 2: Manual
```bash
# 1. SSH ke VPS
ssh root@your_vps_ip

# 2. Create folder
mkdir -p /root/wa-pairing
cd /root/wa-pairing

# 3. Upload files (dari local, di folder lain)
# scp -r web-pairing-complete/* root@your_vps_ip:/root/wa-pairing/

# 4. Setup
sudo bash setup.sh

# 5. Pilih metode (PM2 recommended untuk VPS)
```

## 🔗 Setup Domain + HTTPS

### Step 1: Beli/Gratis Domain
- **Gratis**: Freenom (.ml), Duck DNS
- **Bayar**: Namecheap (.id rp10rb), Hostinger

### Step 2: Point Domain ke VPS
Di control panel domain, set **A Record**:
```
Name: @
Value: YOUR_VPS_IP
TTL: 3600
```

Tunggu 5-30 menit DNS propagate.

### Step 3: Setup Certbot (HTTPS)
```bash
sudo apt update
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com
```

### Step 4: Update Nginx Config
Edit `/etc/nginx/sites-available/wa-pairing`:
```bash
sudo nano /etc/nginx/sites-available/wa-pairing
```

Ganti `yourdomain.com` dengan domain kamu.

Atau copy dari template:
```bash
sudo cp nginx.conf /etc/nginx/sites-available/wa-pairing
```

Test & restart:
```bash
sudo nginx -t
sudo systemctl restart nginx
```

### Step 5: Test HTTPS
Buka `https://yourdomain.com` - harus HTTPS ✅

## ⚙️ Konfigurasi

### .env File
```bash
nano .env
```

Options:
```env
PORT=3000                    # Port server
NODE_ENV=production          # production/development
SESSION_DIR=./sessions       # Folder untuk simpan session
SESSION_TIMEOUT=60000        # Timeout untuk pairing (ms)
LOG_LEVEL=info              # Logging level
```

## 📊 Monitoring

### PM2
```bash
# Lihat status
pm2 status

# Lihat logs real-time
pm2 logs wa-pairing -f

# Restart
pm2 restart wa-pairing

# Stop
pm2 stop wa-pairing
```

### Docker
```bash
# Status
docker-compose ps

# Logs
docker-compose logs -f wa-pairing

# Restart
docker-compose restart wa-pairing

# Stop
docker-compose down
```

### Systemd
```bash
# Status
systemctl status wa-pairing

# Logs
journalctl -u wa-pairing -f

# Restart
systemctl restart wa-pairing
```

## 🔒 Security Tips

1. **Backup sessions**
```bash
tar -czf sessions-backup.tar.gz sessions/
```

2. **Protect .env**
```bash
chmod 600 .env
```

3. **Monitor logs**
```bash
tail -f logs/pm2-out.log
```

4. **Update regularly**
```bash
npm update
npm audit fix
```

## 🐛 Troubleshoot

### Bot tidak connect
```bash
# Check logs
pm2 logs wa-pairing

# Restart
pm2 restart wa-pairing
```

### Port 3000 sudah terpakai
```bash
lsof -i :3000
kill -9 <PID>

# Atau ganti port di .env
PORT=3001
```

### QR code tidak muncul
```bash
npm install qrcode --save
pm2 restart wa-pairing
```

### HTTPS certificate error
```bash
# Renew certificate
sudo certbot renew

# Force renew
sudo certbot renew --force-renewal
```

## 📁 Folder Structure
```
web-pairing-complete/
├── web-pairing.js          # Main server
├── public/
│   └── index.html          # Web UI
├── sessions/               # Bot sessions (auto-created)
├── logs/                   # Log files
├── .env                    # Configuration (edit ini)
├── pm2.config.js          # PM2 config
├── nginx.conf             # Nginx config
├── Dockerfile             # Docker config
├── docker-compose.yml     # Docker Compose
├── setup.sh               # Setup script
├── deploy.sh              # Deploy script
└── package.json           # Dependencies
```

## 🚀 Production Checklist

- [ ] Update .env dengan konfigurasi production
- [ ] Setup domain & HTTPS
- [ ] Test pairing bot (http://domain/api/start-pairing)
- [ ] Setup monitoring (pm2 logs, atau newrelic)
- [ ] Backup sessions folder secara berkala
- [ ] Update SSL certificate (auto via Certbot)
- [ ] Monitor disk space (sessions bisa membesar)
- [ ] Setup error notifications

## 📞 Support

Butuh bantuan? Cek:
1. Logs: `pm2 logs wa-pairing -f`
2. Nginx: `sudo tail -f /var/log/nginx/wa-pairing-error.log`
3. Config: `nano .env`

## 📝 License

MIT - Bebas digunakan untuk project apapun

---

**Happy pairing! 🤖**
